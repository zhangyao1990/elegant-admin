import{t as o}from"./hast-util-to-html-DQqyWRoe.js";function c(t){const s=this.data("settings"),i=Object.assign({},s,t);Object.assign(this,{Compiler:n});function n(e){return o(e,i)}}export{c as r};
