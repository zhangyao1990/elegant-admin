import{u as r}from"./vue-router-B53joON4.js";function n(){const e=r();function o(){e.push({name:"reload"})}return{reload:o}}export{n as u};
