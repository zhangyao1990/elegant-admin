import{u as r}from"./vue-router-A8Zeyv2E.js";function n(){const e=r();function o(){e.push({name:"reload"})}return{reload:o}}export{n as u};
