import{j as a,u as i,a as r}from"./micromark-util-character-BqvJsIbw.js";function u(n){if(n===null||a(n)||i(n))return 1;if(r(n))return 2}export{u as c};
