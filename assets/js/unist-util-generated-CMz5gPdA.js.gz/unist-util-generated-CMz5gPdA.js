function t(i){return!i||!i.position||!i.position.start||!i.position.start.line||!i.position.start.column||!i.position.end||!i.position.end.line||!i.position.end.column}export{t as g};
